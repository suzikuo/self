---
name: Other
about: Not a question, feature request or bug report
title: ""
labels: ""
assignees: ""
---

Please follow this Issue template to provide relevant information, such as source code repositories, blog links, and screenshots, which will help us investigate.
请按照此 Issue 模版提供相关信息，例如源码仓库、博客链接和屏幕截图，这将有助于我们进行调查。

## Issue Checklist <!-- 我确认我已经查看了 -->

<!-- Change [ ] to [x] to select (将 [ ] 换成 [x] 来选择) -->

- [ ] I am using [the latest](https://github.com/Shen-Yu/hexo-theme-ayer) version of hexo-theme-ayer.
- [ ] I have reviewed the latest Roadmap on GitHub and searched for current [Ayer Issues](https://github.com/Shen-Yu/hexo-theme-ayer/issues), which does not help me.

---

## Other Information <!-- Like Browser, System, Screenshots -->
