// 这个文件用来防止 hexo 5.0.0以上 使用 "hexo clean" 命令报错。
// This file is used to prevent hexo above 5.0.0 from using "hexo clean" command error.